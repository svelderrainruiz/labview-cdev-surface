# labview-cdev-cli

Control-plane CLI for deterministic `C:\dev` workspace operations.

## Entrypoint

```powershell
pwsh -NoProfile -File .\scripts\Invoke-CdevCli.ps1 <group> <command> [options]
```

## Commands

- `help [topic]`
- `repos list`
- `repos doctor`
- `surface sync`
- `installer build`
- `installer exercise`
- `installer install`
- `postactions collect`
- `linux install`
- `linux deploy-ni`
- `ci integration-gate`
- `release package`

## Quick Start

```powershell
pwsh -NoProfile -File .\scripts\Invoke-CdevCli.ps1 repos list
pwsh -NoProfile -File .\scripts\Invoke-CdevCli.ps1 repos doctor --workspace-root C:\dev
pwsh -NoProfile -File .\scripts\Invoke-CdevCli.ps1 installer exercise --mode fast --iterations 1
```

## Linux Flow (Docker Desktop Linux)

```powershell
pwsh -NoProfile -File .\scripts\Invoke-CdevCli.ps1 linux install --workspace-root C:\dev-linux
pwsh -NoProfile -File .\scripts\Invoke-CdevCli.ps1 linux deploy-ni --workspace-root C:\dev-linux --docker-context desktop-linux --image nationalinstruments/labview:latest-linux
```

## Release Packaging

```powershell
pwsh -NoProfile -File .\scripts\Invoke-CdevCli.ps1 release package --output-root .\artifacts\release\cli
```

Release artifacts:
- `cdev-cli-win-x64.zip`
- `cdev-cli-linux-x64.tar.gz`
- `.sha256`
- `cdev-cli.spdx.json`
- `cdev-cli.slsa.json`
